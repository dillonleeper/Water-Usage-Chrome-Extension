# Water Usage Tracker - Chrome Extension

A Chrome extension that analyzes your power usage during internet activity and displays the results in terms of water consumption. Track how many gallons of water are used when you browse websites, use ChatGPT, search Google, stream videos, and more.

## Features

- **Real-time Tracking**: Monitors your browsing activity and calculates water consumption in real-time
- **Comprehensive Coverage**: Tracks major websites including:
  - AI services (ChatGPT, Google Gemini, Claude, etc.)
  - Search engines (Google, Bing, Yahoo, DuckDuckGo)
  - Video streaming (YouTube, Netflix, Twitch, Hulu, Disney+, etc.)
  - Social media (Facebook, Instagram, Twitter/X, TikTok, LinkedIn, Reddit)
  - Email services (Gmail, Outlook, Yahoo Mail)
- **Clean & Modern Design**: Beautiful, intuitive interface with gradient colors and smooth animations
- **Activity Breakdown**: See detailed statistics for each website you visit
- **Water Comparisons**: Understand your usage with relatable comparisons (teaspoons, cups, bottles, bathtubs)
- **Data Export**: Export your usage data as JSON for further analysis
- **Session Tracking**: Track when your current session started

## Installation

### Method 1: Load Unpacked Extension (Developer Mode)

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" using the toggle in the top-right corner
3. Click "Load unpacked" button
4. Select the `water-usage-extension` folder
5. The extension icon should now appear in your Chrome toolbar

### Method 2: Drag and Drop (if packaged)

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode"
3. Drag the extension folder or .crx file into the extensions page

## Usage

1. **Click the extension icon** in your Chrome toolbar to open the popup
2. **Start browsing** - The extension automatically tracks your activity
3. **View your stats**:
   - Total water usage (in gallons)
   - Total energy consumption (in kWh)
   - Relatable water comparisons
   - Breakdown by website/service
4. **Export data** - Click the "Export Data" button to download your usage statistics
5. **Reset tracking** - Click the "Reset" button to clear all data and start fresh

## How It Works

The extension uses research-based energy consumption data for different types of internet activities:

- **AI Queries** (ChatGPT, Gemini): ~0.24-0.34 Wh per query
- **Search Engines**: ~0.3 Wh per search
- **Video Streaming**: ~0.08-0.09 kWh per hour
- **Social Media**: ~0.003-0.006 kWh per hour of browsing
- **Email**: ~0.1 Wh per action

Water consumption is calculated using the industry-standard ratio of **2 gallons of water per kWh** of energy, which accounts for both direct cooling and indirect electricity generation.

## Data Sources

The energy consumption estimates are based on:
- OpenAI official disclosures (June 2025)
- Google Cloud sustainability reports (August 2025)
- Independent research from Epoch.AI, IEA, and academic studies
- Industry-standard data center water usage metrics

## Privacy

- All data is stored **locally** on your device using Chrome's storage API
- No data is sent to external servers
- No personal information is collected
- You can reset or export your data at any time

## Technical Details

- **Manifest Version**: 3
- **Permissions**: tabs, storage, webNavigation
- **Storage**: Chrome local storage
- **Update Frequency**: Real-time tracking with 1-minute intervals for time-based activities

## Tips

- AI queries (like ChatGPT) use approximately **10x more water** than regular Google searches
- Video streaming is one of the most water-intensive activities
- The extension tracks time spent on streaming and social media sites
- Export your data regularly to track long-term trends

## Troubleshooting

**Extension not tracking:**
- Make sure you've granted all required permissions
- Try reloading the extension from `chrome://extensions/`
- Check that the extension is enabled

**Stats not updating:**
- Click the extension icon to refresh the popup
- The popup auto-refreshes every 5 seconds when open

**Want to start fresh:**
- Click the "Reset" button in the extension popup
- This will clear all stored data

## Credits

Created with research-based data on internet energy consumption and water usage. Designed with a focus on clean, modern UI/UX principles.

## Version

**1.0.0** - Initial release
